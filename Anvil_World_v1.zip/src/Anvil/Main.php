<?php

namespace Anvil;

use pocketmine\{Server, Player};
use pocketmine\item\{Item, Tool, Armor};
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};

class Main extends PluginBase implements Listener {
    
    public function onEnable(){
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->form = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $this->getLogger()->info("Creador HumYaiJunGz/Editor ElianWorld");
    }
    
    public function onTouch(PlayerInteractEvent $event){
        $block = $event->getBlock();
        $p = $event->getPlayer();
        $item = $p->getInventory()->getItemInHand()->getDamage();
        if($block->getId() === 145){
            $event->setCancelled(true);
            if($p->isSneaking() === false){
                if($item > 0){
                    $this->sendUI($p);
                }else{
                    $p->sendMessage("§6Yunque §f» §eDebes Sostener Una Herramienta En La Mano Y Debe estar Gastada");
                }
            }
        }
    }
    
    public function sendUI(Player $player){
        $form = $this->form->createSimpleForm(function (Player $player, int $data = null){
            $result = $data;
            if($result === null){
                return true;
            }
            switch($result){
                case 0:
                $item = $player->getInventory()->getItemInHand();
                $n = $player->getInventory()->contains(Item::get(452));
                $meta = $item->getDamage();
                $metas = $meta * 1;
                if($n >= $metas){
                    if($item instanceof Armor or $item instanceof Tool){
                        
                    $player->getInventory()->removeItem(Item::get(452,0,$metas));
                    $id = $item->getId();
					      $meta = $item->getDamage();
					      $player->getInventory()->removeItem(Item::get($id, $meta, 1));
					      $newitem = Item::get($id, 0, 1);
					      if($item->hasCustomName()){
						       $newitem->setCustomName($item->getCustomName());
						    }
					      if($item->hasEnchantments()){
						        foreach($item->getEnchantments() as $enchants){
						            $newitem->addEnchantment($enchants);
						       }
						     }
					      $player->getInventory()->addItem($newitem);
					      $player->sendMessage("§6Yunque §f» §eUtilizo §c»§6Pepitas De Hierro§c« §epara reparar §6".$metas." §e¡Reparado! ");
                }else{
                    $player->sendMessage("§6Yunque §f» §ePor favor, sostenga un elemento como equipo o herramientas ");
                    return true;
                }    
            }else{
                $player->sendMessage("§6Yunque §f» §eNo Tienes §c»§6Pepita De Hierro§c« No Puedes Reparar El Objeto");
            }
        }
        });
        $form->setTitle("§6Yunque");
        $metas = $player->getInventory()->getItemInHand()->getDamage();
        $form->addButton("§eRepara\n§c»§6Pepitas De Hierro§c« §a".$metas."§r§0Reparar",0 ,"textures/ui/hammer_l");
        $form->sendToPlayer($player);
    }
}